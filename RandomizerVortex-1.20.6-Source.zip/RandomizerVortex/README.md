# RandomizerVortex

Plugin scoreboard untuk Paper 1.20.6 dan Java 21.

## Build
Jalankan dari folder project:
```bash
mvn clean package
```

Hasil:
`target/RandomizerVortex-1.0.0.jar`

Salin JAR tersebut ke folder `plugins` server Paper.

## Command
- `/vortexsb start [world]`
- `/vortexsb stop`
- `/vortexsb join`
- `/vortexsb leave`
- `/vortexsb status`

Permission admin: `vortex.admin` (default OP)
Permission join: `vortex.join` (default true)

Atur judul, warna, garis progress, dan world default di `src/main/resources/config.yml`.

Catatan: ini source project, bukan file JAR hasil build. Build menggunakan Maven dengan akses ke repositori PaperMC.
