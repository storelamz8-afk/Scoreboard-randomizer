package com.vortex.scoreboard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class VortexScoreboard extends JavaPlugin implements Listener {

    private final Set<UUID> participants = new HashSet<>();
    private final Set<UUID> alive = new HashSet<>();

    private static final String[] ENTRIES = {
            ChatColor.BLACK.toString(),
            ChatColor.DARK_BLUE.toString(),
            ChatColor.DARK_GREEN.toString(),
            ChatColor.DARK_AQUA.toString(),
            ChatColor.DARK_RED.toString(),
            ChatColor.DARK_PURPLE.toString()
    };

    private static final String[] TEAM_NAMES = {
            "vortex1", "vortex2", "vortex3",
            "vortex4", "vortex5", "vortex6"
    };

    private World gameWorld;
    private boolean running;
    private long startTime;
    private Scoreboard board;
    private Objective objective;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        setupScoreboard();
        getServer().getPluginManager().registerEvents(this, this);

        long interval = Math.max(1L,
                getConfig().getLong("scoreboard.update-interval", 20L));

        Bukkit.getScheduler().runTaskTimer(
                this, this::updateScoreboard, 0L, interval
        );

        getLogger().info("Randomizer Vortex Scoreboard enabled.");
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void setupScoreboard() {
        board = Bukkit.getScoreboardManager().getNewScoreboard();

        objective = board.registerNewObjective(
                "vortex", "dummy",
                color(getConfig().getString("scoreboard.title", "&c&lRANDOMIZER VORTEX"))
        );
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        for (int i = 0; i < ENTRIES.length; i++) {
            Team team = board.registerNewTeam(TEAM_NAMES[i]);
            team.addEntry(ENTRIES[i]);
            objective.getScore(ENTRIES[i]).setScore(ENTRIES.length - i);
        }
    }

    private void setLine(int index, String text) {
        Team team = board.getTeam(TEAM_NAMES[index]);
        if (team != null) {
            team.setPrefix(color(text));
        }
    }

    private void updateScoreboard() {
        String progress = getConfig().getBoolean("scoreboard.progress.enabled", true)
                ? getConfig().getString("scoreboard.progress.text", "&8■■■■■■■■■■")
                : "";

        String aliveText =
                getConfig().getString("scoreboard.alive.label", "&cAlive:")
                + " "
                + getConfig().getString("scoreboard.alive.value", "&f")
                + alive.size();

        double borderSize = gameWorld == null
                ? 0.0
                : gameWorld.getWorldBorder().getSize();

        String borderText =
                getConfig().getString("scoreboard.border.label", "&eBorder:")
                + " "
                + getConfig().getString("scoreboard.border.value", "&f")
                + (int) Math.ceil(borderSize)
                + getConfig().getString("scoreboard.border.suffix", "m");

        long elapsed = running
                ? Math.max(0L, (System.currentTimeMillis() - startTime) / 1000L)
                : 0L;

        String timer = String.format("%02d:%02d", elapsed / 60L, elapsed % 60L);
        String timerText =
                getConfig().getString("scoreboard.timer.label", "&bTimer:")
                + " "
                + getConfig().getString("scoreboard.timer.value", "&f")
                + timer;

        setLine(0, progress);
        setLine(1, aliveText);
        setLine(2, " ");
        setLine(3, borderText);
        setLine(4, "  ");
        setLine(5, timerText);

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.setScoreboard(board);
        }
    }

    private void startGame(World world) {
        if (running) {
            return;
        }

        gameWorld = world;
        participants.clear();
        alive.clear();

        for (Player player : world.getPlayers()) {
            participants.add(player.getUniqueId());
            alive.add(player.getUniqueId());
        }

        startTime = System.currentTimeMillis();
        running = true;
        updateScoreboard();

        Bukkit.broadcastMessage(color(
                "&8[&c&lVORTEX&8] &aRandomizer Vortex telah dimulai!"
        ));
        Bukkit.broadcastMessage(color(
                "&8[&c&lVORTEX&8] &fPeserta: &e" + alive.size()
        ));
    }

    private void stopGame() {
        running = false;
        participants.clear();
        alive.clear();
        Bukkit.broadcastMessage(color(
                "&8[&c&lVORTEX&8] &cPertandingan telah dihentikan!"
        ));
        updateScoreboard();
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        UUID uuid = event.getEntity().getUniqueId();

        if (!running || !participants.contains(uuid)) {
            return;
        }

        if (alive.remove(uuid)) {
            Bukkit.broadcastMessage(color(
                    "&8[&c&lVORTEX&8] &c" + event.getEntity().getName()
                    + " &7telah gugur!"
            ));
            updateScoreboard();
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();

        if (running && participants.contains(uuid) && alive.remove(uuid)) {
            Bukkit.broadcastMessage(color(
                    "&8[&c&lVORTEX&8] &c" + event.getPlayer().getName()
                    + " &7keluar dari pertandingan!"
            ));
            updateScoreboard();
        }
    }

    @Override
    public boolean onCommand(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {
        if (!command.getName().equalsIgnoreCase("vortexsb")) {
            return false;
        }

        if (args.length == 0) {
            sender.sendMessage(color("&c/vortexsb start [world]"));
            sender.sendMessage(color("&c/vortexsb stop"));
            sender.sendMessage(color("&c/vortexsb join"));
            sender.sendMessage(color("&c/vortexsb leave"));
            sender.sendMessage(color("&c/vortexsb status"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "start" -> {
                if (!sender.hasPermission("vortex.admin")) {
                    sender.sendMessage(color("&cTidak memiliki izin!"));
                    return true;
                }

                World world = args.length >= 2
                        ? Bukkit.getWorld(args[1])
                        : Bukkit.getWorld(getConfig().getString(
                                "game.default-world", "world"
                        ));

                if (world == null) {
                    sender.sendMessage(color("&cWorld tidak ditemukan!"));
                    return true;
                }

                if (running) {
                    sender.sendMessage(color("&cGame sudah berjalan!"));
                    return true;
                }

                startGame(world);
                sender.sendMessage(color("&aGame berhasil dimulai!"));
            }

            case "stop" -> {
                if (!sender.hasPermission("vortex.admin")) {
                    sender.sendMessage(color("&cTidak memiliki izin!"));
                    return true;
                }
                if (!running) {
                    sender.sendMessage(color("&cTidak ada game berjalan!"));
                    return true;
                }
                stopGame();
                sender.sendMessage(color("&cGame dihentikan!"));
            }

            case "join" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Perintah ini hanya bisa digunakan pemain.");
                    return true;
                }
                if (!running) {
                    player.sendMessage(color("&cGame belum dimulai!"));
                    return true;
                }
                if (!player.hasPermission("vortex.join")) {
                    player.sendMessage(color("&cTidak memiliki izin!"));
                    return true;
                }
                if (player.getWorld() != gameWorld) {
                    player.sendMessage(color("&cKamu tidak berada di world pertandingan!"));
                    return true;
                }

                participants.add(player.getUniqueId());
                alive.add(player.getUniqueId());
                player.sendMessage(color("&aBerhasil bergabung ke pertandingan!"));
                updateScoreboard();
            }

            case "leave" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Perintah ini hanya bisa digunakan pemain.");
                    return true;
                }
                participants.remove(player.getUniqueId());
                alive.remove(player.getUniqueId());
                player.sendMessage(color("&cKamu keluar dari pertandingan!"));
                updateScoreboard();
            }

            case "status" -> {
                sender.sendMessage(color("&8&m----------------------"));
                sender.sendMessage(color("&c&lRANDOMIZER VORTEX"));
                sender.sendMessage(color("&fStatus: "
                        + (running ? "&aRunning" : "&cStopped")));
                sender.sendMessage(color("&fAlive: &e" + alive.size()));
                sender.sendMessage(color("&fParticipants: &e" + participants.size()));
                sender.sendMessage(color("&8&m----------------------"));
            }

            default -> sender.sendMessage(color("&cPerintah tidak dikenal!"));
        }

        return true;
    }
}
